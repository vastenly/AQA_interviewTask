package Triangle;

public class RtriangleProvider implements Rtriangle{

	public static Rtriangle getRtriangle() {
		return new RtriangleProvider();
	}
	
	public int getApexX1() {
		return 1;
	}

	public int getApexY1() {
		return 3;
	}

	public int getApexX2() {
		return 4;
	}

	public int getApexY2() {
		return 1;
	}

	public int getApexX3() {
		return 1;
	}

	public int getApexY3() {
		return 1;
	}
	
}
